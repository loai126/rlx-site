
document.getElementById('mineBtn').onclick = function() {
    alert('تم بدء التعدين! الرجاء العودة بعد 24 ساعة.');
    this.disabled = true;
    this.style.backgroundColor = 'gray';
};
document.getElementById('connectWallet').onclick = function() {
    alert('جارٍ ربط محفظتك...');
};
